package com.lemon.spider.pmc;

import com.lemon.commons.ThreadSafeSleep;
import org.apache.http.HttpHeaders;
import org.apache.http.HttpHost;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.AuthCache;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.protocol.HttpClientContext;
import org.apache.http.impl.auth.BasicScheme;
import org.apache.http.impl.client.BasicAuthCache;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicHeader;
import org.apache.http.util.EntityUtils;
import org.jsoup.Connection;
import org.jsoup.Jsoup;
import org.omg.PortableInterceptor.SYSTEM_EXCEPTION;

import java.io.*;

/**
 * Created by bob on 2017/1/17.
 */
public class Xproxy {

    private final static String CERT_HOME = "/Library/Java/JavaVirtualMachines/jdk1.8.0_102.jdk/Contents/Home/jre/lib/security/cacerts";
    private final static String UrlPrefix4Jsoup = "http://pubmedcentralcanada.ca";
    private final static String Blocked = "[blocked]";

    private Xproxy() {}

    private static HttpHost target;
    private static RequestConfig config;
    private static CloseableHttpClient httpclient;
    private static HttpClientContext ctx;
    private static HttpHost proxy;

    static {
        CredentialsProvider credsProvider = new BasicCredentialsProvider();
        credsProvider.setCredentials(
                new AuthScope("proxy.crawlera.com", 8010),
                new UsernamePasswordCredentials("1bd66098acef4410b8eec210c15a1d68", "")); //

        try {
            httpclient = HttpClients.custom()
                    .setDefaultCredentialsProvider(credsProvider)
                    .build();
            target = new HttpHost("pubmedcentralcanada.ca", 80, "http");
            proxy = new HttpHost("proxy.crawlera.com", 8010);

            AuthCache authCache = new BasicAuthCache();

            BasicScheme basicAuth = new BasicScheme();
            basicAuth.processChallenge(
                    new BasicHeader(HttpHeaders.PROXY_AUTHENTICATE,
                            "Basic realm=\"Crawlera\""));
            authCache.put(proxy, basicAuth);

            ctx = HttpClientContext.create();
            ctx.setAuthCache(authCache);

            config = RequestConfig.custom()
                    .setProxy(proxy)
                    .build();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static String getHtml(String url, boolean localFirst) {
        ++Spider.Total_Requests;

        if(localFirst) {
            try {
                String text = Jsoup.connect(UrlPrefix4Jsoup + url).get().html();
                text = checkBlockStatus(text, url);
                if(!Blocked.equalsIgnoreCase(text)) {
                    System.out.println("200:  " + url);
                    return text;
                }
            } catch (Exception e) {
                System.out.println("[warn]  first loading failed, try another way. " + url);
                //nothing do, to jump to the following get methods.

            }
        }

        int retry = 4;
        String rt = doProxyGetHtml(url);
        while(Blocked.equalsIgnoreCase(rt) && retry>0) { //如果失败了,休眠一会之后,再次尝试,这个时候可能会以另外的ip去访问。
            --retry;
            System.out.println("[Retry Later]:  Use Proxy still got blocked!!!");
            ThreadSafeSleep.sleep(2000);
            rt = doProxyGetHtml(url);
        }
        System.out.println("Pxy:  " + url);
        return rt;
    }

    private static String doProxyGetHtml(String url) {
        HttpGet httpget = new HttpGet(url);
        httpget.setConfig(config);

        try {
            CloseableHttpResponse response = httpclient.execute(target, httpget, ctx);
            String text = EntityUtils.toString(response.getEntity());
            EntityUtils.consume(response.getEntity());

            return checkBlockStatus(text, url);
        } catch (Exception e) {
            System.err.println("Err: " + httpget.getRequestLine());
            e.printStackTrace();
        }
        return null;
    }

    private static String checkBlockStatus(String text, String url) {
        if(text.indexOf("Bulk downloading of content", ParserPaper.skipHead) >= 0) {
            System.out.println("[Blocked]:  try other way. " + url);
            return Blocked; //
        }
        if(text.indexOf("Page not available</h1>", ParserPaper.skipHead) >= 0) {
            System.out.println("[NA-Skip]:  Page not available. " + url);
            return null; //
        }
        return text;
    }


    public static boolean download2File(String url, File dstFile) {
        ++Spider.Total_Requests;

        BufferedOutputStream bos = null;
        if(!url.endsWith(".pdf")) {
            try {
                Connection.Response response = Jsoup.connect(UrlPrefix4Jsoup + url).ignoreContentType(true).execute();
                bos = new BufferedOutputStream(new FileOutputStream(dstFile));
                bos.write(response.bodyAsBytes());
                bos.flush();

                System.out.println(response.statusCode() + ":  " + url);
                return true;
            } catch (Exception e) {
                System.out.println("[warn]  first loading failed, try another way. " + url);
                //nothing do, to jump to the following get methods.

            } finally {
                if (bos != null) {
                    try {
                        bos.close();
                    } catch (Exception e) {
                    }
                }
            }
        }

        int retry = 3;
        boolean rt = doProxyDownload2File(url, dstFile);
        while(!rt && retry>0) { //如果失败了,休眠一会之后,再次尝试,这个时候可能会以另外的ip去访问。
            --retry;
            ThreadSafeSleep.sleep(2000);
            rt = doProxyDownload2File(url, dstFile);
        }
        return rt;
    }

    private static boolean doProxyDownload2File(String url, File dstFile) {
        HttpGet httpget = new HttpGet(url);
        httpget.setConfig(config);
        BufferedInputStream bis = null;
        BufferedOutputStream bos = null;
        try {
            //Open a URL Stream
            CloseableHttpResponse response = httpclient.execute(target, httpget, ctx);
            if(response.getStatusLine().getStatusCode() != 200) {
                return false;
            }

            bis = new BufferedInputStream(response.getEntity().getContent());
            bos = new BufferedOutputStream(new FileOutputStream(dstFile));
            int got;
            byte[] cache = new byte[1024*1024];
            while((got=bis.read(cache)) != -1) {
                bos.write(cache, 0, got);
            }
            bos.flush();

            System.out.println(response.getStatusLine().getReasonPhrase() + " :  " + httpget.getRequestLine().getUri());

            return true;
        } catch (Exception e) {
            System.err.println("Er: " + httpget.getRequestLine());
            e.printStackTrace();
            return false;
        } finally {
            if(bos != null) {
                try {
                    bos.close();
                } catch (Exception e) {}
            }

            if(bis != null) {
                try {
                    bis.close();
                } catch (Exception e) {}
            }
        }
    }

}
