package com.lemon.spider.pmc;

import com.lemon.commons.ThreadSafeSleep;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

/**
 * Created by bob on 2017/1/13.
 */
public class Spider {

    public static int Total_Requests = 0;
    public static int Total_Papers = 0;
    public static int Total_Failed = 0;
    public static int Total_Skiped = 0;
    public static int PMC_Start = 4000000;
    public static int PMC_Stop =  4200000;
    public static String WWWROOTDir = "/Users/bob/Sites/med/";
    public final static long APP_Start = System.currentTimeMillis();
    public static ApplicationContext context = null;

    public static void main(String[] args) throws Exception {
        System.out.println("\nusage:\njava -jar lemontools.jar [threads] [start] [stop] [root] ");

        int threads = 100;
        if(args.length >= 1) {
            threads = Integer.parseInt(args[0]);
        }
        if(args.length >= 2) {
            PMC_Start = Integer.parseInt(args[1]);
        }
        if(args.length >= 3) {
            PMC_Stop = Integer.parseInt(args[2]);
        }
        if(args.length >= 4) {
            WWWROOTDir = args[3];
        }

        System.out.println("\nusage:\njava -jar lemontools.jar threads=" + threads + " start=" + PMC_Start + " stop=" + PMC_Stop + " root=" + WWWROOTDir);

        try {
            context = new FileSystemXmlApplicationContext("classpath*:applicationContext.xml");

            for(int i=0; i<threads; i++) {
                ParserPaper main = new ParserPaper(threads, i, false);
//                if(i<5) {
//                    main = new ParserPaper(threads, i, true);
//                } else {
//                    main = new ParserPaper(threads, i, false);
//                }
                main.start();
                ThreadSafeSleep.sleep(4000);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
