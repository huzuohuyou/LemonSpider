delete from lwtask;
delete from lwuser;