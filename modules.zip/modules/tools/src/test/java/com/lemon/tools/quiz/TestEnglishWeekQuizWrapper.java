package com.lemon.tools.quiz;

import org.junit.Test;

public class TestEnglishWeekQuizWrapper {

	@Test
	public void test() {
		//		String s = FileUtil.readAllText("./aa-2.html");
		//		String s2 = new QuestWrapper(1).deepOptimizieOptionsTable(s);
		//		FileUtil.writeAllText(s2, "./aa-3.html");
	}

}
