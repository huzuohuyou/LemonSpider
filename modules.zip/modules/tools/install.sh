#!/bin/bash

echo "[INFO] Install jar to local repository."

mvn clean assembly:assembly
