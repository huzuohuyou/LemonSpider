package com.lemon.commons.util.ds;
//package com.lemon.util.ds;
//
//import org.hibernate.Session;
//
//import com.woshi.ds.po.finance.Ticket;
//import com.woshi.ds.po.um.User;
//
//public class RebateStruct {
//	
//	//事件code
//	private Integer code;
//	//用户类型
//	private User user;
//	//计算出积分变化值
//	private Integer scoreDelta;
//	//券类型对象
//	private Ticket ticket;
//	//额外的参数
//	private String additionalPara;
//	//数据库链接
//	private Session session;
//	
//	public Integer getCode() {
//		return code;
//	}
//	public void setCode(Integer code) {
//		this.code = code;
//	}
//	public User getUser() {
//		return user;
//	}
//	public void setUser(User user) {
//		this.user = user;
//	}
//	public Integer getScoreDelta() {
//		return scoreDelta;
//	}
//	public void setScoreDelta(Integer scoreDelta) {
//		this.scoreDelta = scoreDelta;
//	}
//	public String getAdditionalPara() {
//		return additionalPara;
//	}
//	public void setAdditionalPara(String additionalPara) {
//		this.additionalPara = additionalPara;
//	}
//	public Session getSession() {
//		return session;
//	}
//	public void setSession(Session session) {
//		this.session = session;
//	}
//	public Ticket getTicket() {
//		return ticket;
//	}
//	public void setTicket(Ticket ticket) {
//		this.ticket = ticket;
//	}
//	
//}