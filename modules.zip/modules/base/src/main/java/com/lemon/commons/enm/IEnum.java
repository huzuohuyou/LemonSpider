package com.lemon.commons.enm;
/** 
 * @author bob 北京易智享科技有限公司
 * @version v3 2015年5月14日 上午11:20:26
 * 
 */
public interface IEnum {
	int getCode();
	String getValue();
}
