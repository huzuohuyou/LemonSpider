package com.lemon.commons;

public final class Dict {
	public final static class User {
		public final static Integer NEED_FILL_USER_INFORMATION = 0;
		public final static Integer FILLED_USER_INFORMATION = 1;
		public final static Character TEACHER = 't';
		public final static Character STUDENT = 's';
	}
}
