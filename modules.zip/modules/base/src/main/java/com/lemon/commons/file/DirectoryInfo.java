package com.lemon.commons.file;

/**
 * Created by yp on 2015/8/25.
 */
public class DirectoryInfo {
    private String name;
    private String dir;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDir() {
        return dir;
    }

    public void setDir(String dir) {
        this.dir = dir;
    }
}
