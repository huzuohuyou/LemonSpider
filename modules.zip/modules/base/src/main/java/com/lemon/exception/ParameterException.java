package com.lemon.exception;

public class ParameterException extends LemonServiceException{

	private static final long serialVersionUID = 5738914157573866125L;

	public ParameterException(String msg) {
		super(msg);
		// TODO Auto-generated constructor stub
	}

}
